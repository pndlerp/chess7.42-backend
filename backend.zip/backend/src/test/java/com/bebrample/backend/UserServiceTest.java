package com.bebrample.backend;

import com.bebrample.backend.common.exception.ResourcesNotFoundException;
import com.bebrample.backend.common.security.JwtService;
import com.bebrample.backend.user.UserMapper;
import com.bebrample.backend.user.UserMapperImpl;
import com.bebrample.backend.user.UserRepository;
import com.bebrample.backend.user.UserService;
import com.bebrample.backend.user.dto.UserCreateDto;
import com.bebrample.backend.user.dto.UserResponseDto;
import com.bebrample.backend.user.entity.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Spy
    private UserMapper userMapper = new UserMapperImpl();

    @Mock
    private JwtService jwtService;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private UserService userService;

    private User user;
    private UserCreateDto userCreateDto;

    @BeforeEach
    void createUserAndDto(){
        user = User.builder().id(1L).username("bebrik").password("encodedPassword").build();
        userCreateDto = new UserCreateDto("bebrik", "rawPassword");
    }

    @Test
    void findById_WhenUserExists_ShouldReturnUserDto(){

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));

        UserResponseDto result = userService.findById(1L);

        assertNotNull(result);
        assertEquals(user.getUsername(), result.getUsername());
    }

    @Test
    void findByid_WhenUserNotFound_ShouldThrowException(){
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(ResourcesNotFoundException.class, () -> userService.findById(1L));
    }

    @Test
    void login_WhenSuccessfully_ShouldReturnToken(){
        when(userRepository.findUserByUsername(user.getUsername())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches(userCreateDto.getPassword(), user.getPassword())).thenReturn(true);
        when(jwtService.generateToken(user.getId().toString(),user.getUsername(), "ROLE_USER")).thenReturn("mockedJwt");

        String token = userService.login(userCreateDto);

        assertNotNull(token);
        assertEquals("mockedJwt", token);

    }

    @Test
    void login_WhenUserNotFound_ShouldThrowException(){
        when(userRepository.findUserByUsername(user.getUsername())).thenReturn(Optional.empty());

        assertThrows(ResourcesNotFoundException.class, () -> userService.login(userCreateDto));
    }

    @Test
    void login_WhenPasswordIsIncorrect_ShouldThrowException(){
        when(userRepository.findUserByUsername(user.getUsername())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches(userCreateDto.getPassword(), user.getPassword())).thenReturn(false);

        assertThrows(ResourcesNotFoundException.class, () -> userService.login(userCreateDto));
    }

    @Test
    void registration_WhenSuccessfully_ShouldReturnDto(){
        when(userRepository.findUserByUsername(userCreateDto.getUsername())).thenReturn(Optional.empty());

        UserResponseDto userResponseDto = userService.register(userCreateDto);

        assertEquals(user.getUsername(), userResponseDto.getUsername());
        verify(userRepository, times(1)).save(any());
    }

    @Test
    void registration_WhenUsernameAlreadyInDb_ShouldThrowException(){
        when(userRepository.findUserByUsername(userCreateDto.getUsername())).thenReturn(Optional.of(user));


        assertThrows(ResourcesNotFoundException.class, () -> userService.register(userCreateDto));
        verify(userRepository, times(1)).findUserByUsername(user.getUsername());
    }


}
