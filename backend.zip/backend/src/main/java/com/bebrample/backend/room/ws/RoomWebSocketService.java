package com.bebrample.backend.room.ws;

import com.bebrample.backend.room.RedisRepository;
import com.bebrample.backend.room.ws.dto.MessageDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RoomWebSocketService {
    private final RedisRepository redisRepository;

    public void saveMessage(String roomUuid, MessageDto message){
        redisRepository.saveMessage(roomUuid, message);
    }

    public List<MessageDto> getMessages(String roomUuid){
       return redisRepository.getMessages(roomUuid);
    }
}
