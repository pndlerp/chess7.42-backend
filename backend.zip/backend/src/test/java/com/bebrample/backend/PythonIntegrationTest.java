package com.bebrample.backend;

import com.bebrample.backend.chess.ChessService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.context.ImportTestcontainers;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(properties = "jwt.secret=secretKey123")
@EnableAutoConfiguration(exclude = DataSourceAutoConfiguration.class)
@ImportTestcontainers(TestContainersConfiguration.class)
public class PythonIntegrationTest {


    @Autowired
    private ChessService chessService;

    @Test
    void testPythonReturningDto(){
        var result = chessService.makeMove("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1", "e2e4");
        assertNotNull(result);
        System.out.println(result);
    }
}
