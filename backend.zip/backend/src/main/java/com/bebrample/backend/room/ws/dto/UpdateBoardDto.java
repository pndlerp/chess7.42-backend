package com.bebrample.backend.room.ws.dto;

import com.bebrample.backend.entity.RoomState;

public class UpdateBoardDto {
    String fen;
    RoomState roomState;
    boolean isCheck;

}
