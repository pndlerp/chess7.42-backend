package com.bebrample.backend;

import com.bebrample.backend.user.UserRepository;
import com.bebrample.backend.user.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.context.ImportTestcontainers;
import org.springframework.context.annotation.Import;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest(properties = "jwt.secret=secretKey123")
@ImportTestcontainers(TestContainersConfiguration.class)
public class IDunnoTest {
    @Autowired
    private UserRepository userRepository;

    @Test
    void ShouldSaveUser(){
        User user = userRepository.save(User.builder()
                .username("bebra")
                .password("password")
                .build());
        assertThat(user.getId()).isNotNull();
    }

    @Test
    void shouldSuccessfullyCreateUser_AndSaveHimToDb(){

    }
}
