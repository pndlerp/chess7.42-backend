package com.bebrample.backend;

import com.bebrample.backend.chess.ChessService;
import com.bebrample.backend.chess.MakeMoveResponseDto;
import com.bebrample.backend.common.exception.ResourcesNotFoundException;
import com.bebrample.backend.common.exception.RoomException;
import com.bebrample.backend.entity.Color;
import com.bebrample.backend.entity.RoomState;
import com.bebrample.backend.room.RedisRepository;
import com.bebrample.backend.room.Room;
import com.bebrample.backend.room.RoomService;
import com.bebrample.backend.room.ws.dto.MoveDto;
import com.bebrample.backend.user.entity.LobbyParticipant;
import com.bebrample.backend.user.entity.LobbyParticipantMapper;
import com.bebrample.backend.user.entity.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.messaging.simp.SimpMessagingTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RoomServiceTest {

    @Mock
    private RedisRepository redisRepository;

    @Mock
    private SimpMessagingTemplate simpMessagingTemplate;

    @Mock
    private ChessService chessService;

    @InjectMocks
    private RoomService roomService;

    @Spy
    LobbyParticipantMapper lobbyParticipantMapper;
    private LobbyParticipant particip;
    private LobbyParticipant particip2;
    private Room testRoom;
    private MakeMoveResponseDto moveDto;
    private MoveDto move;

//    @BeforeEach
//    @AfterEach
//    void setUp(){
//         particip = User.builder().id(1L).username("bebrik").password("password").build();
//         particip2 = User.builder().id(2L).username("bebrik2").password("password").build();
//         testRoom = Room.builder().uuid("123")
//                 .roomState(RoomState.WAITING_FOR_OPPONENT)
//                 .firstPlayer(lobbyParticipantMapper.toUserLobbyDto(particip))
//                 .secondPlayer(null)
//                 .currentFen(null)
//                 .activeColor(null)
//                 .legal_moves(null)
//                 .build();
//         moveDto = new MakeMoveResponseDto(null, null, null);
//         move = new MoveDto("e1", "e1", null);
//    }
//
//    @Test
//    void createRoom_WhenSuccessfully_ShouldReturnRoom(){
//        when(redisRepository.isPlaying(particip.getId())).thenReturn(false);
//
//        Room room = roomService.createRoom(particip);
//        assertNotNull(room);
//    }
//
//    @Test
//    void createRoom_WhenPlayerIsPlaying_ShouldThrowException(){
//        when(redisRepository.isPlaying(particip.getId())).thenReturn(true);
//
//        assertThrows(RoomException.class, () -> roomService.createRoom(particip));
//        verify(redisRepository).isPlaying(particip.getId());
//        verifyNoMoreInteractions(redisRepository);
//    }
//
//    @Test
//    void connectToRoom_WhenSuccessfully_ShouldReturnRoom(){
//        when(redisRepository.isPlaying(particip.getId())).thenReturn(false);
//        when(redisRepository.getRoom(testRoom.getUuid())).thenReturn(testRoom);
//        Room returnedRoom = roomService.connectToRoom(testRoom.getUuid(), particip);
//
//        assertNotNull(returnedRoom);
//        assertNotNull(returnedRoom.getFirstPlayer());
//        assertNotNull(returnedRoom.getSecondPlayer());
//        System.out.println(returnedRoom.getFirstPlayer().getColor());
//        System.out.println(returnedRoom.getSecondPlayer().getColor());
//    }
//
//    @Test
//    void connectToRoom_WhenPlayerIsPlaying_ShouldThrowException(){
//        when(redisRepository.isPlaying(particip.getId())).thenReturn(true);
//
//        assertThrows(RoomException.class, () -> roomService.connectToRoom(testRoom.getUuid(), particip));
//    }
//
//    @Test
//    void connectToRoom_WhenRoomIsNull_ShouldThrowException(){
//        when(redisRepository.isPlaying(particip.getId())).thenReturn(false);
//        when(redisRepository.getRoom(testRoom.getUuid())).thenReturn(null);
//
//        assertThrows(RoomException.class, () -> roomService.connectToRoom(testRoom.getUuid(), particip));
//    }
//
//    @Test
//    void connectToRoom_WhenSecondPlayerIsNotNull_ShouldThrowException(){
//        testRoom.setSecondPlayer(lobbyParticipantMapper.toUserLobbyDto(particip2));
//        when(redisRepository.isPlaying(particip.getId())).thenReturn(false);
//        when(redisRepository.getRoom(testRoom.getUuid())).thenReturn(testRoom);
//
//        assertThrows(RoomException.class, () -> roomService.connectToRoom(testRoom.getUuid(), particip));
//    }
//
//    @Test
//    void updateChessState_WhenSuccessfully_ShouldDoNothing(){
//        testRoom.setRoomState(RoomState.ONGOING);
//        testRoom.setActiveColor(Color.WHITE);
//        testRoom.setSecondPlayer(lobbyParticipantMapper.toUserLobbyDto(particip2));
//        testRoom.getFirstPlayer().setColor(Color.WHITE);
//        when(redisRepository.getRoom(testRoom.getUuid())).thenReturn(testRoom);
//        when(redisRepository.getUserRoomUuid(particip.getId())).thenReturn(testRoom.getUuid());
//        when(chessService.makeMove(null, "e1e1")).thenReturn(moveDto);
//
//        roomService.updateChessState(testRoom.getUuid(), move, particip);
//
//        verify(redisRepository).updateRoom(testRoom);
//    }
//
//    @Test
//    void updateChessState_WhenRoomIsNull_ShouldThrowException(){
//        testRoom.setRoomState(RoomState.ONGOING);
//        when(redisRepository.getRoom(testRoom.getUuid())).thenReturn(null);
//
//        assertThrows(ResourcesNotFoundException.class, () -> roomService.updateChessState(testRoom.getUuid(), move, particip));
//    }
//
//    @Test
//    void updateChessState_WhenGameIsFinished_ShouldThrowException(){
//        testRoom.setRoomState(RoomState.DRAW);
//        when(redisRepository.getRoom(testRoom.getUuid())).thenReturn(testRoom);
//
//        assertThrows(RoomException.class, () -> roomService.updateChessState(testRoom.getUuid(), move, particip));
//    }
//
//    @Test
//    void updateChessState_WhenPlayerNotPlayingThisGame_ShouldThrowException(){
//        testRoom.setRoomState(RoomState.ONGOING);
//        when(redisRepository.getRoom(testRoom.getUuid())).thenReturn(testRoom);
//        when(redisRepository.getUserRoomUuid(particip.getId())).thenReturn(null);
//
//        assertThrows(RoomException.class, () -> roomService.updateChessState(testRoom.getUuid(), move, particip));
//    }
//
//    @Test
//    void updateChessState_WhenNotPlayersMove_ShouldThrowException(){
//        testRoom.setActiveColor(Color.WHITE);
//        testRoom.getFirstPlayer().setColor(Color.BLACK);
//        testRoom.setRoomState(RoomState.ONGOING);
//        when(redisRepository.getRoom(testRoom.getUuid())).thenReturn(testRoom);
//        when(redisRepository.getUserRoomUuid(particip.getId())).thenReturn(testRoom.getUuid());
//
//        assertThrows(RoomException.class, () -> roomService.updateChessState(testRoom.getUuid(), move, particip));
//    }

}

