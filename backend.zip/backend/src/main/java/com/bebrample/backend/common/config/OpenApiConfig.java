package com.bebrample.backend.common.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Chess API Specification")
                        .version("1.0.0")
                        .description(getWebSocketDocumentation()));
    }

    private String getWebSocketDocumentation() {
        return """
        # WebSocket & STOMP Documentation
        ### 1. Connection
        * **WebSocket Endpoint:** `ws://localhost:8080/ws`
        * STOMP over WebSocket
        ### 2. Destinations & Topics
        
        #### Subscribe Topic
        * **Destination:** `/topic/rooms/{roomId}`
        * **Description:** Clients subscribe to this topic to receive updated room state after each move or player event.
        
        #### Send Move Destination
        * **Destination:** `/app/rooms/{roomId}/move`
        * **Description:** Sends a player's move to the server.
        
        ---
        
        ### 3. Data Structures & Messages
        
        #### Request: Send Move (Move Payload)
        **Destination:** `/app/rooms/{roomId}/move`
        ```json
        {
          "from": "e2",        // (Required) Source square (Algebraic notation)
          "to": "e4",          // (Required) Destination square
          "promotion": "q"     // (Optional) Piece for pawn promotion (q, r, b, n)
        }
        ```
        
        #### Response / Event: Room State (Room Payload)
        **Destination:** `/topic/rooms/{roomId}`
        
        The server broadcasts the `Room` object (or wrapped as `{"type": "...", "payload": Room}`):
        
        ```json
        {
          "currentFen": "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1",
          "roomState": "IN_PROGRESS", // Possible values: WAITING, IN_PROGRESS, FINISHED
          "activeColor": "BLACK",       // Possible values: WHITE, BLACK
          "firstPlayer": {
            "id": 1,
            "username": "GrandmasterFlex",
            "color": "WHITE"
          },
          "secondPlayer": {
            "id": 2,
            "username": "OpponentPlayer",
            "color": "BLACK"
          }
        }
        ```
        """;
    }
}